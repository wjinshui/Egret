declare module skins{
	class ButtonSkin extends eui.Skin{
	}
}
declare module skins{
	class CheckBoxSkin extends eui.Skin{
	}
}
declare module skins{
	class HScrollBarSkin extends eui.Skin{
	}
}
declare module skins{
	class HSliderSkin extends eui.Skin{
	}
}
declare class ImageButtonSkin extends eui.Skin{
}
declare class ImageLabelSkin extends eui.Skin{
}
declare module skins{
	class ItemRendererSkin extends eui.Skin{
	}
}
declare module skins{
	class MyButtonSkin extends eui.Skin{
	}
}
declare module skins{
	class PanelSkin extends eui.Skin{
	}
}
declare module skins{
	class ProgressBarSkin extends eui.Skin{
	}
}
declare module skins{
	class RadioButtonSkin extends eui.Skin{
	}
}
declare module skins{
	class ScrollerSkin extends eui.Skin{
	}
}
declare class TableControlSkin extends eui.Skin{
}
declare module skins{
	class TextInputSkin extends eui.Skin{
	}
}
declare module skins{
	class ToggleSwitchSkin extends eui.Skin{
	}
}
declare module skins{
	class VScrollBarSkin extends eui.Skin{
	}
}
declare module skins{
	class VSliderSkin extends eui.Skin{
	}
}
declare class BasicCharaItemSkin extends eui.Skin{
}
declare class CourtSkin extends eui.Skin{
}
declare class GuanzhiBiaoSkin extends eui.Skin{
}
declare class PalaceSkin extends eui.Skin{
}
declare class PreloadSkin extends eui.Skin{
}
declare class SetNameSkin extends eui.Skin{
}
declare class StartSkin extends eui.Skin{
}
declare class TempSceneSkin extends eui.Skin{
}
declare class TestSceneSkin extends eui.Skin{
}
