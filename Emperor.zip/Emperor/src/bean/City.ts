class City
{
    public name:string;
    public country:string;
}
